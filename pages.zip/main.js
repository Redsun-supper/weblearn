// document表示整个HTML文档对象，addEventListener为文档添加事件监听器
// 'DOMContentLoaded'事件在HTML文档完全加载并解析完成后触发，不等待图片等外部资源加载
// 使用此事件确保DOM元素已准备好，可以安全地操作DOM
document.addEventListener('DOMContentLoaded', function() {
    // console.log向浏览器开发者工具的控制台输出日志信息，用于调试和验证代码执行
    // 此处输出提示信息，确认页面DOM已成功加载
    console.log('Page loaded successfully');
    
    // 使用querySelectorAll选中所有class为nav-rect的导航矩形项元素，返回NodeList集合
    const navRects = document.querySelectorAll('.nav-rect');
    
    // 使用getElementById获取内容容器元素，用于显示加载的HTML内容
    const contentContainer = document.getElementById('contentContainer');
    
    // 缓存配置：30天（毫秒）
    const CACHE_EXPIRY = 30 * 24 * 60 * 60 * 1000;
    const CACHE_PREFIX = 'pageCache_';
    const CACHE_META_KEY = 'pageCache_meta';
    
    // 获取缓存元数据（记录每个页面的最后访问时间）
    function getCacheMeta() {
        try {
            const meta = localStorage.getItem(CACHE_META_KEY);
            return meta ? JSON.parse(meta) : {};
        } catch (e) {
            console.error('读取缓存元数据失败:', e);
            return {};
        }
    }
    
    // 保存缓存元数据
    function saveCacheMeta(meta) {
        try {
            localStorage.setItem(CACHE_META_KEY, JSON.stringify(meta));
        } catch (e) {
            console.error('保存缓存元数据失败:', e);
        }
    }
    
    // 清理过期缓存
    function cleanExpiredCache() {
        const meta = getCacheMeta();
        const now = Date.now();
        let cleaned = false;
        
        for (const pageName in meta) {
            const lastAccess = meta[pageName];
            if (now - lastAccess > CACHE_EXPIRY) {
                // 删除过期的缓存内容
                localStorage.removeItem(CACHE_PREFIX + pageName);
                delete meta[pageName];
                cleaned = true;
                console.log('清理过期缓存:', pageName);
            }
        }
        
        if (cleaned) {
            saveCacheMeta(meta);
        }
    }
    
    // 从localStorage获取缓存的HTML内容
    function getCachedContent(pageName) {
        try {
            return localStorage.getItem(CACHE_PREFIX + pageName);
        } catch (e) {
            console.error('读取缓存内容失败:', e);
            return null;
        }
    }
    
    // 将HTML内容保存到localStorage
    function saveCachedContent(pageName, html) {
        try {
            localStorage.setItem(CACHE_PREFIX + pageName, html);
        } catch (e) {
            // 如果存储空间不足，清理过期缓存后重试
            if (e.name === 'QuotaExceededError') {
                cleanExpiredCache();
                try {
                    localStorage.setItem(CACHE_PREFIX + pageName, html);
                } catch (e2) {
                    console.error('存储空间不足，无法缓存:', pageName);
                }
            } else {
                console.error('保存缓存内容失败:', e);
            }
        }
    }
    
    // 更新缓存访问时间
    function updateAccessTime(pageName) {
        const meta = getCacheMeta();
        meta[pageName] = Date.now();
        saveCacheMeta(meta);
    }
    
    // 页面加载时清理过期缓存
    cleanExpiredCache();
    
    // 使用forEach遍历每个导航矩形项元素，为每个元素添加点击事件监听器
    navRects.forEach(function(rect) {
        // 为当前导航矩形项添加点击事件监听器，当用户点击时触发回调函数
        rect.addEventListener('click', function() {
            // 再次使用forEach遍历所有导航矩形项，移除每个元素的active类
            navRects.forEach(function(r) {
                // classList.remove移除指定的CSS类名，清除之前激活的状态
                r.classList.remove('active');
            });
            // 为当前被点击的导航矩形项添加active类，使其背景色变为灰色并保持
            this.classList.add('active');
            
            // 使用getAttribute获取当前元素的data-page属性值，即要加载的HTML文件名
            const pageName = this.getAttribute('data-page');
            
            // 更新访问时间
            updateAccessTime(pageName);
            
            // 检查localStorage中是否存在缓存
            const cachedHtml = getCachedContent(pageName);
            if (cachedHtml) {
                // 如果缓存中存在，直接使用缓存的HTML内容更新内容容器
                contentContainer.innerHTML = cachedHtml;
                // 在控制台输出日志，表明使用了缓存
                console.log('使用本地缓存加载:', pageName);
            } else {
                // 如果缓存中不存在，在内容容器中显示加载中的提示文字
                contentContainer.innerHTML = '<p class="placeholder-text">正在加载内容...</p>';
                
                // 使用fetch API发起请求，兼容HTTPS协议
                fetch(pageName)
                    .then(function(response) {
                        if (!response.ok) {
                            throw new Error('文件加载失败');
                        }
                        return response.text();
                    })
                    .then(function(html) {
                        // 保存到localStorage永久缓存
                        saveCachedContent(pageName, html);
                        // 显示内容
                        contentContainer.innerHTML = html;
                        console.log('首次加载并永久缓存:', pageName);
                    })
                    .catch(function(error) {
                        console.error('加载错误:', error);
                        contentContainer.innerHTML = '<p class="placeholder-text">内容加载失败，请检查文件是否存在</p>';
                    });
            }
        });
    });
// 匿名函数结束，作为事件回调函数
});